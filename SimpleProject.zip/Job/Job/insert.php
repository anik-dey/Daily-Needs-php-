<?php
  
       
	  if (isset($_POST['submit'])) 
	   {       
	        $name=$_POST['name'];
			$username=$_POST['username'];
			$password=$_POST['pass'];
			$email=$_POST['email'];
           // $optradio=$_POST['optradio'];
            

			   	if($name == "")
			   	{
			   		
			       $error_msg['name'] = "Name is require";

			 	}

		        else if(!preg_match("/^[a-zA-Z -]*$/",$name))
		        {
		        	
		        	$error_msg['name']="Only letters are allowed";
		        }	

		       
		       
		       
	           else if(empty($_POST['optradio']))
	            {
	            	
	            	$error_msg['optradio']="Gender is require";
	            	
	            }

	            else if(empty($username))
	            {
	            	
	            	
	            	$error_msg['username']="Username is require";
	            	
	            }

	            else if (!(preg_match("/^[A-Za-z][A-Za-za-z0-9]{5,100}$/",$username))) 
	             {
	             	
	             	
	             	$error_msg['username']="Length at least 6 require ";
	             	
	             }

	            
	             
	            else if(empty( $password))
	            {
	            	
	            	
	            	$error_msg['pass']="Password is require";
	            	
	            }

	           
	            else if(strlen($password)<6) 
	            {
	            
	            	$error_msg['pass4']="Password at least 6 Length";
	            	
	            }
	             
	            else if(!filter_var($email,FILTER_VALIDATE_EMAIL))
	            {
	            	
	            	$error_msg['email']="Invalid email";
	            
	            } 
			                
			      
          
	   if(!$error_msg)
	    {
            
	   		$type="1";
	   		$gender=$_POST['optradio'];
            
			    $con=mysqli_connect("localhost","root","","job");
				if(!$con)
				{
					die("Connection Error: ".mysqli_connect_error()."<br/>");
				}
				//Row Insert

				$sql="INSERT INTO rgtn (name,username,password,email,gender,type) VALUES('$name','$username','$password','$email','$gender','$type')";
				if(mysqli_query($con,$sql))
				{
                   
                    header("Location:admin_home.php");
				}
				else
				{ 
                    
					echo "Error in inserting: ".mysqli_error($con);
				}
			  
			  mysqli_close($con);	

		}	

	      echo"Please try again !!";     
   }


 
   
  

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Added users</h2>
  <p>Please Insert New Users:</p>
  <form action="<?= htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <label for="usr">Name:</label>
      <input type="text" class="form-control" id="name" name="name">
    </div>
    <div class="form-group">
      <label for="usr">Username:</label>
      <input type="text" class="form-control" id="usr" name="username">
    </div>

    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pass" name="pass">
    </div>

    <div class="form-group">
      <label for="pwd">Email:</label>
      <input type="text" class="form-control" id="email" name="email">
    </div>
    
    <div class="form-check-inline">
  <label class="form-check-label">
    <input type="radio" class="form-check-input" name="optradio" value="Male">Male
  </label>
</div>
<div class="form-check-inline">
  <label class="form-check-label">
    <input type="radio" class="form-check-input" name="optradio" value="Female">Female
  </label>
</div>
<div class="form-check-inline disabled">
  <label class="form-check-label">
    <input type="radio" class="form-check-input" name="optradio" value="Others" disabled>Others
  </label>
</div>
<br>
<br>
<br>
    <button type="submit" class="btn btn-primary" name="submit">Added</button>
  </form>
</div>

</body>
</html>