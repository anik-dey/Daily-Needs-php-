<?php
if (isset($_POST['submit']))
{
    $id=$_POST['id'];
    if($id == "")
    {
        
    $error_msg['id'] = "Id is require";

    }
   
    
    if(!$error_msg)
    {

    $con=mysqli_connect("localhost","root","","job");
    if(!$con)
    {
        die("Connection Error: ".mysqli_connect_error()."<br/>");
    }
    //Row Insert

    $sql="DELETE  FROM rgtn WHERE id='$id'";
    $result=mysqli_query($con,$sql);
    if(mysqli_query($con,$sql))
    {
        header("Location:admin_home.php");
    }
    else
    {
        echo "Error in inserting: ".mysqli_error($con);
    }
  
  mysqli_close($con);	

} 
}   
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Delete Form</h2>
  <p>Please Delete Users Data:</p>
  <p class="text-danger">Id must be Required.</p>
  <form action="<?= htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST" enctype="multipart/form-data">
  <div class="form-group">
      <label for="usr">Id:</label>
      <input type="text" class="form-control" id="id" name="id">
    </div>
    <div class="form-group">
    <button type="submit" class="btn btn-danger" name="submit">Delete</button>
  </form>
</div>

</body>
</html>