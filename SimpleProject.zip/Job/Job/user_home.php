<?php
session_start();
if(!isset($_SESSION['id']))
{
	header("Location:login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Bootstrap Example</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<?php
		$id=$_SESSION['id'];
		
?>
<div class="container">
  <h2>User Home</h2>
  <p>The .dropdown-header class is used to add headers inside the dropdown menu:</p>
  <div class="dropdown">
    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
      Dropdown button
    </button>
    <div class="dropdown-menu">
      <h5 class="dropdown-header">Dropdown header</h5>
      <a class="dropdown-item" href="user_update.php">Update</a>
      
    </div>
  </div>
</div>
<table align="center">
		<tr>
            <td><h4 style="color:black;">We Ensure Your Safety.</h4></td>
            <td>
            <a href="http://localhost/job/logout.php">Click here to Logout</a>
    	</td>
		</tr>
	</table>

</body>
</html>