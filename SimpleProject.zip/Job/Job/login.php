<?php
session_start();
$hdr="";
 if (isset($_POST['submit']))
 {

 	$username=$_POST['username'];
 	$password=$_POST['password'];
 	if($_POST['username'] == "")
 	{
 		$error_msg['username']="Username cannot be empty";
 	}
 	if($_POST['password'] == "")
 	{
 		$error_msg['password']="Password cannot be empty";
 	}

 	
 	$con=mysqli_connect("localhost","root","","job");
	if(!$con)
	{
		die("Connection Error: ".mysqli_connect_error()."<br/>");
	}
	//Retrieve Data

	$password=$_POST['password'];
	$username=$_POST['username'];
	$sql="SELECT * FROM rgtn WHERE username='$username' AND password='$password'";
	$result=mysqli_query($con,$sql);	
	if(mysqli_num_rows($result)>0)
	{
		$row=mysqli_fetch_array($result);
		$_SESSION['name']=$row['name'];
		$_SESSION['status']=$row['type'];
		$_SESSION['id']=$row['id'];
		$id=$_SESSION['id'];
		if($_SESSION['status']==1)
		{
			
			header("Location:user_home.php");
			exit();
			
		}

		

		else if($_SESSION['status']==0)
		{
			header("Location:admin_home.php");
		}
		//header("Location:home.php");
	}
	else
	{
		echo "No data found.<br/>";
	}

	
      mysqli_close($con);		
      


 } 

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Login Form</h2>
  <p>The form below contains two input elements; one of type text and one of type password:</p>
  <form action="<?= htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <label for="usr">Username:</label>
      <input type="text" class="form-control" id="usr" name="username">
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="password" name="password">
    </div>
    
    <button type="submit" class="btn btn-primary" name="submit">Login</button>
    <table align="center">
		<tr>
            <td><h4 style="color:black;">Kindly login to help us to serve you better.</h4></td>
            <td>
            <a href="http://localhost/job/reg.php">Click here to Registration</a>
    	</td>
		</tr>
	</table>
  </form>
</div>

</body>
</html>

