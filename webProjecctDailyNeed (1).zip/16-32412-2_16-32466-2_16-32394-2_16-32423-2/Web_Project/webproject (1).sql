-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2019 at 02:05 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `evening`
--

CREATE TABLE `evening` (
  `id` int(15) NOT NULL,
  `name` varchar(15) NOT NULL,
  `phoneNumber` varchar(15) NOT NULL,
  `email` varchar(15) NOT NULL,
  `type` varchar(15) NOT NULL,
  `amount` int(15) NOT NULL,
  `area` varchar(15) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `evening`
--

INSERT INTO `evening` (`id`, `name`, `phoneNumber`, `email`, `type`, `amount`, `area`, `date`) VALUES
(9, 'Rupom', '00000000000', 'rupam@gamil.com', 'electrician', 1000, 'banani', '2019-04-28');

-- --------------------------------------------------------

--
-- Table structure for table `hired`
--

CREATE TABLE `hired` (
  `name` varchar(10) NOT NULL,
  `schedule` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `phone` varchar(15) NOT NULL,
  `type` varchar(10) NOT NULL,
  `id` int(15) NOT NULL,
  `id1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hired`
--

INSERT INTO `hired` (`name`, `schedule`, `date`, `phone`, `type`, `id`, `id1`) VALUES
('Srejoni', '8am - 11am', '2019-04-28', '01751973982', 'electricia', 9, 7),
('Russel', '8am - 11am', '2019-04-28', '01715308627', 'electricia', 12, 8),
('Russel', '8am - 11am', '2019-04-28', '01715308627', 'electricia', 12, 9),
('Jeson', '8am - 11am', '2019-04-28', '01715308621', 'clamber', 13, 10),
('Rupom', '8am - 11am', '2019-04-28', '01751973982', 'electricia', 9, 11);

-- --------------------------------------------------------

--
-- Table structure for table `inbox`
--

CREATE TABLE `inbox` (
  `id` int(11) NOT NULL,
  `sender` varchar(30) NOT NULL,
  `receiver` varchar(30) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inbox`
--

INSERT INTO `inbox` (`id`, `sender`, `receiver`, `message`) VALUES
(3, 'ratul@gmail.com', 'Admin', 'Hi how are you'),
(4, 'Admin', 'ratul@gmail.com', 'i am fine'),
(5, 'anik@gmail.com', 'Admin', '8 number'),
(6, 'ratul@gmail.com', 'Admin', 'defence day'),
(7, 'Admin', 'ratul@gmail.com', 'my defence today');

-- --------------------------------------------------------

--
-- Table structure for table `morning`
--

CREATE TABLE `morning` (
  `id` int(10) NOT NULL,
  `name` varchar(15) NOT NULL,
  `phoneNumber` varchar(15) NOT NULL,
  `email` varchar(15) NOT NULL,
  `type` varchar(15) NOT NULL,
  `amount` int(10) NOT NULL,
  `area` varchar(15) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `morning`
--

INSERT INTO `morning` (`id`, `name`, `phoneNumber`, `email`, `type`, `amount`, `area`, `date`) VALUES
(13, 'Jeson', '01715308621', 'jeson@gmail.com', 'clamber', 740, 'banani', '2019-04-28'),
(15, 'biplobkumar', '01751973982', 'biplob@gmail.co', 'electrician', 350, 'gulshan', '2019-04-28');

-- --------------------------------------------------------

--
-- Table structure for table `noon`
--

CREATE TABLE `noon` (
  `id` int(15) NOT NULL,
  `name` varchar(15) NOT NULL,
  `phoneNumber` varchar(15) NOT NULL,
  `email` varchar(15) NOT NULL,
  `type` varchar(15) NOT NULL,
  `amount` int(15) NOT NULL,
  `area` varchar(15) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `noon`
--

INSERT INTO `noon` (`id`, `name`, `phoneNumber`, `email`, `type`, `amount`, `area`, `date`) VALUES
(9, 'Srejoni', '01751973982', 'rupam@gamil.com', 'electrician', 450, 'gulshan', '2019-04-28'),
(12, 'Russel', '01715308627', 'russel@gmail.co', 'electrician', 500, 'kilkhet', '2019-04-28');

-- --------------------------------------------------------

--
-- Table structure for table `registrationtable`
--

CREATE TABLE `registrationtable` (
  `id` int(10) NOT NULL,
  `name` varchar(15) NOT NULL,
  `phoneNumber` varchar(15) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `email` varchar(15) NOT NULL,
  `status` int(5) NOT NULL,
  `type` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrationtable`
--

INSERT INTO `registrationtable` (`id`, `name`, `phoneNumber`, `gender`, `username`, `password`, `email`, `status`, `type`) VALUES
(7, 'Anik', '01851973981', 'male', 'anikdey', '123456', 'anik@gmail.com', 0, 'admin'),
(9, 'Rupom', '00000000000', 'Male', 'rupomkumar', '123456', 'rupam@gamil.com', 2, 'electrician'),
(11, 'Ratull', '01715308624', 'Male', 'ratulkumar', '123456', 'ratul@gmail.com', 1, 'customers'),
(12, 'Russel', '01715308627', 'Female', 'russelkumar', '123456', 'russel@gmail.co', 2, 'electrician'),
(13, 'Jeson', '01715308621', 'Female', 'jesonkumar', '123456', 'jeson@gmail.com', 2, 'clamber'),
(14, 'Akash', '01744778888', 'Male', 'akashkumar', '123456', 'akash@gmail.com', 1, 'customers'),
(15, 'biplobkumar', '01751973982', 'Male', 'biplobkumar', '123456', 'biplob@gmail.co', 2, 'electrician');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `evening`
--
ALTER TABLE `evening`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hired`
--
ALTER TABLE `hired`
  ADD PRIMARY KEY (`id1`);

--
-- Indexes for table `inbox`
--
ALTER TABLE `inbox`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `morning`
--
ALTER TABLE `morning`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `noon`
--
ALTER TABLE `noon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registrationtable`
--
ALTER TABLE `registrationtable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hired`
--
ALTER TABLE `hired`
  MODIFY `id1` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `inbox`
--
ALTER TABLE `inbox`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `registrationtable`
--
ALTER TABLE `registrationtable`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
