


<?php
  
       
	  if (isset($_POST['submit'])) 
	   {       
	        $name=$_POST['name'];
			$phone=$_POST['phone'];
			$username=$_POST['username'];
			$password=$_POST['pass'];
			$pass2=$_POST['pass2'];
			$email=$_POST['email'];
			$type=$_POST['type'];

			   	if($name == "")
			   	{
			   		
			       $error_msg['name'] = "Name is require";

			 	}

		        else if(!preg_match("/^[a-zA-Z -]*$/",$name))
		        {
		        	
		        	$error_msg['name']="Only letters are allowed";
		        }	

		        else if($phone == "")
			   	{
			   		
			       $error_msg['phone'] = "Phone Num is require";
			    
			    }   
			       
			    else if (!is_numeric($phone)) 
			   	{
			   		
			   	   $error_msg['phone']="Only Number input";
			   		
			   	}
			   	else if(strlen($phone) !=11)
			   	{
			   		
			   		
			   		$error_msg['phone']="Only input 11 digits number";
			   		
			   	}
			   
		        else if($_POST['type'] =="NULL")
		        {
		        
		        	 $error_msg['type'] = "Type is require";
		        	 
		        }
		       
	           else if(empty($_POST['sex']))
	            {
	            	
	            	$error_msg['sex']="Gender is require";
	            	
	            }

	            else if(empty($username))
	            {
	            	
	            	
	            	$error_msg['username']="Username is require";
	            	
	            }

	            else if (!(preg_match("/^[A-Za-z][A-Za-za-z0-9]{5,100}$/",$username))) 
	             {
	             	
	             	
	             	$error_msg['username']="Length at least 6 require ";
	             	
	             }

	            
	             
	            else if(empty( $password))
	            {
	            	
	            	
	            	$error_msg['pass']="Password is require";
	            	
	            }

	            else if(empty( $pass2))
	            {
	            	
	            	$error_msg['pass2']="Confirm Password is require";
	            	
	            }

	            else if ($password!=$pass2) 
	            {
	            	
	            	$error_msg['pass3']="You need to give password and Confirm Password both are same";
	            	
	            }
	            else if(strlen($password)<6) 
	            {
	            
	            	$error_msg['pass4']="Password at least 6 Length";
	            	
	            }
	             
	            else if(!filter_var($email,FILTER_VALIDATE_EMAIL))
	            {
	            	
	            	$error_msg['email']="Invalid email";
	            
	            } 
			                
			        $initial = filter_input(INPUT_POST, "type");//GET the input in post method
			        if ($initial == "customers") {
			            $initial_value = 1;
			        } elseif ($initial == "clamber") {
			            $initial_value = 2;
			        } elseif ($initial == "electrician") {
			            $initial_value = 2;
			        } elseif ($initial == "cleaner") {
			            $initial_value = 2;
			        } else {
			            //$initial_value = "Select initial";
			        }
          
	   if(!$error_msg)
	    {
	   		$status=$initial_value;
	   		$gender=$_POST['sex'];

			    $con=mysqli_connect("localhost","root","","webproject");
				if(!$con)
				{
					die("Connection Error: ".mysqli_connect_error()."<br/>");
				}
				//Row Insert

				$sql="INSERT INTO registrationtable (name,phoneNumber,gender,username,password,email,status,type) VALUES('$name','$phone','$gender','$username','$password','$email','$status','$type')";
				if(mysqli_query($con,$sql))
				{
					header("Location:user_login.php");
				}
				else
				{
					echo "Error in inserting: ".mysqli_error($con);
				}
			  
			  mysqli_close($con);	

		}	

	           
   }


 
   
  

?>



<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
</head>

<body style="background-color:purple;">
       <img src="image/rgtn.jpg">
	   <h1 align="center">DAILY NEEDS</h1>
       <h2 align="center">Registration Form</h2>
       <p align="center">
       <font size="2" face="arial" color="red">
   	   All (*) mark field are require
        </font>
       </p>

 <form action="<?= htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST" enctype="multipart/form-data">
	<table align="center">
		<tr class="row">
			<td class="label"><label for="name">Full Name</label></td><br/>
			<td><input type="text" name="name" id="name" placeholder="*Full Name" value="<?php echo isset($_POST['name']) ? $_POST['name'] : ''; ?>"/>

				<?php
				if (isset($error_msg['name'])) 
				{
					echo $error_msg['name'];
				}
				?>

			</td>
		</tr>

		<tr class="row">
			<td class="label"></td>
		</tr>
		<tr class="row">
			<td class="label"></td>
		</tr>

        <tr class="row">
			<td class="label"><label for="email">Email</label></td>
			<td><input type="text" name="email" id="email" placeholder="*@gmail.com" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>"/>
              <?php
				if (isset($error_msg['email'])) 
				{
					echo $error_msg['email'];
				}
				?>
			</td>
		</tr>

		<tr class="row">
			<td class="label"></td>
		</tr>
		<tr class="row">
			<td class="label"></td>
		</tr>

        <tr class="row">
			<td class="label"><label for="phone">Phone Number</label></td>
			<td><input type="text" name="phone" id="phone" placeholder="*Phone(01XXXXXXXXX)" value="<?php echo isset($_POST['phone']) ? $_POST['phone'] : ''; ?>"/>
            
            <?php
				if (isset($error_msg['phone'])) 
				{
					echo $error_msg['phone'];
				}
				?>

			</td>
		</tr>
		<tr class="row">
			<td class="label"></td>
		</tr>
		<tr class="row">
			<td class="label"></td>
		</tr> 
         <tr class="row">
			<td class="label"><label for="sex">Gender</label></td>
			<td><input type="radio" name="sex" id="sex" value="Male" 
                 <?php if(isset($sex) && $sex='Male')echo 'checked="checked"';?>
				/>

				<label for="sex">Male</label>
				<input type="radio" name="sex" value="Female" id="sex"  
				<?php if(isset($sex) && $sex='Female')echo 'checked="checked"';?>/>
				<label for="">Female</label>
				 <?php
				if (isset($error_msg['sex'])) 
				{
					echo $error_msg['sex'];
				}
				?>

			</td>
		</tr>
        
        <tr class="row">
			<td class="label"></td>
		</tr>
		<tr class="row">
			<td class="label"></td>
		</tr> 
        

        <tr class="row">
        	<td class="label"><label for="type">Type</label></td>
        	<td>
        		<select class="text" name="type" id="type">
        			<option value="NULL">--*Select Type--</option>
        			<option value="customers">Customers</option>
        			<option value="clamber">Clamber</option>
        			<option value="electrician">Electrician</option>
        			<option value="cleaner">Cleaner</option>

        		</select>
        		 <?php
				if (isset($error_msg['type'])) 
				{
					echo $error_msg['type'];
				}
				?>
        	</td>
        	
        </tr>

         <tr class="row">
			<td class="label"></td>
		</tr>
		<tr class="row">
			<td class="label"></td>
		</tr>

		<tr class="row">
			<td class="label"><label for="username">User Name</label></td>
			<td><input type="text" name="username" id="username" placeholder="*Username" value="<?php echo isset($_POST['username']) ? $_POST['username'] : ''; ?>"/>
              <?php
				if (isset($error_msg['username'])) 
				{
					echo $error_msg['username'];
				}
				?>
			</td>
		</tr>
        
        <tr class="row">
			<td class="label"></td>
		</tr>
		<tr class="row">
			<td class="label"></td>
		</tr> 


		<tr class="row">
			<td class="label"><label for="pass">Password</label></td>
			<td><input type="password" name="pass" id="pass" placeholder="*Password"/>
             <?php
				if (isset($error_msg['pass'])) 
				{
					echo $error_msg['pass'];
				}
				/*else if (isset($error_msg['pass3'])) 
				{
					echo $error_msg['pass3'];
				}*/
				else if (isset($error_msg['pass4'])) 
				{
					echo $error_msg['pass4'];
				}
				?>

			</td>
		</tr>

        <tr class="row">
			<td class="label"></td>
		</tr>
		<tr class="row">
			<td class="label"></td>
		</tr> 
		
		<tr class="row">
			<td class="label"><label for="pass2">Confirm Password</label></td>
			<td><input type="password" name="pass2" id="pass2" placeholder="*Confirm Password"/>
             
             <?php
				if (isset($error_msg['pass2'])) 
				{
					echo $error_msg['pass2'];
				}
				else if (isset($error_msg['pass3'])) 
				{
					echo $error_msg['pass3'];
				}
				 else if (isset($error_msg['pass4'])) 
				{
					echo $error_msg['pass4'];
				}
				?>


			</td>
		</tr>

		 <tr class="row">
			<td class="label"></td>
		</tr>
		<tr class="row">
			<td class="label"></td>
		</tr> 
		

       <tr>
       	<td colspan="2"><input type="submit" name="submit" value="SUBMIT"/></td>
       	
       	<td></td>
       	<tr>
       		<td><a href="user_login.php"><input type="button" name="login_btn" value="Click here to Login"></a></td>
       	</tr>
       </tr>

        <tr class="row">
			<td class="label"><label for="phone"><h4 style="color:DodgerBlue;">Already Registered ??<a href="user_login.php">Login to continue...</</h4></label></td>
			
	
	</table>

	<table align="center">
		<tr>
			<td><h4 style="color:black;">Kindly register to help us to serve you better.</h4></td>
		</tr>
	</table>
	
  </form>

     <style>

		/* unvisited link */
		a:link {
		  color: red;
		}

		/* visited link */
		a:visited {
		  color: green;
		}

		/* mouse over link */
		a:hover {
		  color: hotpink;
		}

		/* selected link */
		a:active {
		  color: blue;
		}
	</style>
</body>
</html>
user_rgtn.php
Displaying user_rgtn.php.