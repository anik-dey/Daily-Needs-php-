<?php
session_start();
load();
if(!isset($_SESSION['name']))
{
	header("Location:user_login.php");
}
?>

<html>
<head>
<title>
</title>
</head>
<body style="background-color:gray;">
<?php
		$name=$_SESSION['name'];
		
		?>
<h3 align="left"><a href="worker_home.php"><img src="images.png" height="60px" width="110px" ></a></h3>
<h3 align="right"><a href="logout.php">Log Out</a>
<h3 align="right"><a href="worker_TimeSet.php">Edit Schedule</a>
<h1 align="center">DAILY NEEDS</h1>
<!--<form method="post">
<table align="right">
<tr>
<td>
Delete Your Shift
</td>
</tr>
<tr>
<td>
<select class="text" name="time" id="time">
      <option value="NULL">--Select Schedule--</option>
      <option value="morning">Morning</option>
      <option value="noon">Noon</option>
      <option value="evening">Evening</option>
  
     </select></td>
     </tr>
     <tr>
     <td><input type="submit" name="submit" value="Delete"></td>
     </tr>
</table>
</form>!-->
 
   
   
   <h2 align="center">My Current Job</h2>
        <table border="0.1" cellpadding="40%" align="center" width="50%">
          <tr >
           <th>Morning</th>
           <th>Noon</th>
           <th>Evening</th>
          </tr>
          <tr>
            <td>8-11am</td>
            <td><label>11am-2pm</label></td>
            <td><label>2pm-5pm</label></td>
          </tr> 
           <tr>
           <td><label>Area:</label><label><?php echo isset($_SESSION['area']) ? $_SESSION['area'] : ''; ?></label></td>
           <td><label>Area:</label><label><?php echo isset($_SESSION['area1']) ? $_SESSION['area1'] : ''; ?></label></td>
            <td><label>Area:</label><label><?php echo isset($_SESSION['area2']) ? $_SESSION['area2'] : ''; ?></label></td>
          </tr>
           <tr>
           <td><label>Amount:</label><label><?php echo isset($_SESSION['amount']) ? $_SESSION['amount'] : ''; ?></label></td>
            <td><label>Amount:</label><label><?php echo isset($_SESSION['amount1']) ? $_SESSION['amount1'] : ''; ?></label></td>
            <td><label>Amount:</label><label><?php echo isset($_SESSION['amount2']) ? $_SESSION['amount2'] : ''; ?></label></td>
          </tr>
        </table>
</body>
</html>
<?php
function load()
{
 $id=$_SESSION['id'];
 
 $con=mysqli_connect("localhost","root","","webproject");
 if(!$con)
  {
   die("Connection Error: ".mysqli_connect_error()."<br/>");
   }
   $id=$_SESSION['id'];
   $con=mysqli_connect("localhost","root","","webproject");
   if(!$con)
   {
     die("Connection Error: ".mysqli_connect_error()."<br/>");
     }

     $sql="SELECT * FROM morning WHERE id='$id'";
     $result=mysqli_query($con,$sql);
     if(mysqli_num_rows($result)>0)
 {
   $row=mysqli_fetch_array($result);
       $_SESSION['amount']=$row['amount'];
       $_SESSION['area']=$row['area'];
       
 }   

 $sql="SELECT * FROM noon WHERE id='$id'";
 $result=mysqli_query($con,$sql);
 if(mysqli_num_rows($result)>0)
{
$row=mysqli_fetch_array($result);
   $_SESSION['amount1']=$row['amount'];
   $_SESSION['area1']=$row['area'];
   
   
}   

$sql="SELECT * FROM evening WHERE id='$id'";
$result=mysqli_query($con,$sql);
if(mysqli_num_rows($result)>0)
{
$row=mysqli_fetch_array($result);
  $_SESSION['amount2']=$row['amount'];
  $_SESSION['area2']=$row['area'];
  
}   

}

?>
<?php
 /*if(isset($_POST['submit']))
 {
    $id=$_SESSION['id'];

     $time=$_POST['time'];
     
    
     if($time == "morning")
     {
        $con=mysqli_connect("localhost","root","","webproject");
         if(!$con)
    {
      die("Connection Error: ".mysqli_connect_error()."<br/>");
    }
     

     $sql="DELETE FROM morning WHERE id='$id'";
     $result=mysqli_query($con,$sql);
  }

 else if($time == "noon")
 {
    $con=mysqli_connect("localhost","root","","webproject");
     if(!$con)
{
  die("Connection Error: ".mysqli_connect_error()."<br/>");
}
 
 
 $sql="DELETE FROM noon WHERE id='$id'";
 $result=mysqli_query($con,$sql);
 }
 else if($time == "evening")
 {
    $con=mysqli_connect("localhost","root","","webproject");
     if(!$con)
{
  die("Connection Error: ".mysqli_connect_error()."<br/>");
}
 

 $sql="DELETE FROM evening WHERE id='$id'";
 $result=mysqli_query($con,$sql);
 
 }
 
 }*/
?>