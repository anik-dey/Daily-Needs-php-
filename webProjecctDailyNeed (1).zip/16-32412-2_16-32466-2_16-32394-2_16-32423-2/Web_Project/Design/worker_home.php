<?php
session_start();
if(!isset($_SESSION['name']))
{
	header("Location:user_login.php");
}
?>

<html>
<head><title>Workers</title></head>
<body style="background-color:gray;">
<?php
		$name=$_SESSION['name'];
		
		?>
    <table width="100%" style="background-color:lightblue;">
        <tr align="right" style="background-color:lightblue;">
		    <td align="left"style="background-color:lightblue;"><a href="worker_home.php"><img src="images.png" height="60px" width="110px" ></a></td>
			<td style="background-color:lightblue;" >
			
			<form>
			    <a href="worker_hired.php">Hired</a>
				
					
					
				   
				
			    
				
			
			</form>
			
			</td>
			<td style="background-color:lightblue;">
			<form>
			  
				<ul style="list-style-type:none;"> 
				    <li><a href="worker_TimeSet.php">My Job</a></li>
					<li><a href="worker_Currentjob.php">Current Job</a></li>
					
					
				   
				</ul>
			    
                
			
			</form>
			</td>
			<td>
			    <ul style="list-style-type:none;"> 
				    <li><a href="worker_profile.php">My Profile</a></li>
					<li><a href="worker_RemoveAccount.php">Remove Account</a></li>
					</ul>
			    
			
			
			</td>
			<td style="background-color:lightblue;"><a href="logout.php">Log Out</a></td>
		<tr>
	</table><br/>
	<table width="100%">
	    <tr> 
		    <td style="background-color:lightgray;">
			<marquee style="background-color:lightorange"><h1>Active More Earn More</h1></marquee>
			
			
			
			</td>
		
		
		</tr>
	
	</table>
	
	
	
	
<a href="terms_policy.php"><h4>Terms and Polices</h4></a>
</body>
</html>