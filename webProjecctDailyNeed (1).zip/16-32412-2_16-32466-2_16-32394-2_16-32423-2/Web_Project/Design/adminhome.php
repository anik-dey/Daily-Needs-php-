<?php
session_start();
if(!isset($_SESSION['name']))
{
	header("Location:user_login.php");
}
?>

<html>
<head><title>Admin</title>
<script>
function showHint(str) {
  if (str.length == 0) { 
   
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  else 
  {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "gethint.php?q=" + str, true);
    xmlhttp.send();
  }
}
</script>
</head>
<body style="background-color:gray;">
<?php
		$name=$_SESSION['name'];
		
		?>
    <table width="100%" style="background-color:lightblue;">
        <tr align="right" style="background-color:lightblue;">
		    <td align="left"style="background-color:lightblue;"><a href="adminhome.php"><img src="images.png" height="60px" width="110px" ></a></td>
			<td style="background-color:lightblue;" >
			
			<form method="POST" action="gethint1.php">
			    What are you looking for?
			    <input type="search"name="search"value=""onkeyup="showHint(this.value)">
				<input type="submit" name="search1"value="Search"></br>
				<span id="txtHint"></span>
				
			</form>
			
			</td>
			<td style="background-color:lightblue;">
			<form>
			   <a href="adminview.php" target=""> Worker Details</a>
				<ul> 
				    
					
				   
				</ul>
			    
                
			
			</form>
			</td>

            <td style="background-color:lightblue;"><a href="workHistory.php">Worked History</a></td>
			<td style="background-color:lightblue;"><a href="admindetails.php">My Details</a></td>
			
			<td style="background-color:lightblue;"><a href="a_inbox1.php">Inbox</a></td>
			<td style="background-color:lightblue;"><a href="logout.php">Log Out</a></td>
			
		<tr>
	</table><br/>
	<table width="100%">
	    <tr> 
		    <td style="background-color:lightgray;">
			<marquee style="background-color:lightorange"><h1>Welcome Admin Pannel</h1></marquee>
			
			
			
			</td>
		
		
		</tr>
	
	</table>
	
	
	
	

    

</body>
</html>