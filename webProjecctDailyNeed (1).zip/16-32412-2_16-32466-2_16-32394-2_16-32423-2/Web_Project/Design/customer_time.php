<?php
session_start();
if(!isset($_SESSION['name']))
{
	header("Location:user_login.php");
}
?>
<html>
<head><title>Customer</title></head>
<body>
<body style="background-color:cyan;">
<?php
		$name=$_SESSION['name'];
		
		?>
  <table align="center">
  <a href="customer_home.php"><img src="images.png" height="60px" width="110px" ></a></td>
  <h3 align="right"><a href="logout.php">Log Out</a>
  <h1 align="center">Daily Needs</h1>
  
  <tr>
			  <td>  <a href="customer_MorningSearch.php">Morning (8am - 11am)</a></td>

    </tr> 
    <tr>           
             <td>   <a href="customer_NoonSearch.php">Noon (11am - 2pm)</a></td>
                </tr>
                <tr>
            <td>   <a href="customer_EveningSearch.php">Evening (2pm - 5pm)</a></td>
				
			    </tr>
				
			
			
            </table>
</body>
</html>