<html>
<head><title>customer  Inbox</title></head>
<body style="background-color:gray;">
    <table width="100%" style="background-color:lightblue;">
        <tr align="right" style="background-color:lightblue;">
		    <td align="left"style="background-color:lightblue;"><a href="customer_home.php"><img src="images.png" height="60px" width="110px" ></a></td>
			<td style="background-color:lightblue;" >
			
			
			</td>
			<td style="background-color:lightblue;">
			</td>
			
			<td style="background-color:lightblue;"><a href="user_login.php">Log Out</a></td>
		<tr>
		<tr>
		<td>
		<Form align="center"method="POST" action="cdb.php">
		From:</br>
		<input type="email"name="cfrom" value=""placeholder="Enter your Email"></br>
		To:</br>
        <input type="text"name="cto" value="" placeholder="Type 'Admin' here"></br>	
        Message:</br>

       <input type="text"name="cmessage"value=""placeholder=" Enter your message here...">
        </br></br>
        <input type="submit"name="submit1"value="Send">
         </form>
		
		
		</td>
		
		
		</tr>
		</table>
		
		</body>
		</html>