<html>
<head><title>Workers</title></head>
<body style="background-color:gray;">
    <table width="100%" style="background-color:lightblue;">
        <tr align="right" style="background-color:lightblue;">
		    <td align="left"style="background-color:lightblue;"><a href="index.php"><img src="images.png" height="60px" width="110px" ></a></td>
			<td style="background-color:lightblue;" >
			
			<form>
			  
				
			
			</form>
			
			</td>
			<td style="background-color:lightblue;">
			<form>
			   
			    
                
			
			</form>
			</td>
			<td style="background-color:lightblue;"><a href="terms_Policy.php">About this site..</a></td>
			<td style="background-color:lightblue;"><a href="user_login.php">Log In</a></td>
		<tr>
	</table><br/>
	<table width="100%">
	    <tr> 
		    <td style="background-color:lightgray;">
			<marquee style="background-color:lightorange"><h1>Thank you, For visiting Our Website. Stay with us.</h1></marquee>
			<marquee><h1>Sign up for free and Get unbeliveable Offers..Grab your offer now...</h1></marquee>
			
			
			
			</td>
		
		
		</tr>
	
	</table>
	
	
	
	


<a href="terms_Policy.php"><h4>Turms and Polices</h4></a>
</body>
</html>