<?php
session_start();
if(!isset($_SESSION['name']))
{
	header("Location:user_login.php");
}
?>

<html>
<head><title>Customer</title></head>
<body style="background-color:gray;">
<?php
		$name=$_SESSION['name'];
		
		?>
    <table width="100%" style="background-color:lightblue;">
        <tr align="right" style="background-color:lightblue;">
		    <td align="left"style="background-color:lightblue;"><a href="customerhome.php"><img src="images.png" height="60px" width="110px" ></a></td>
			<td style="background-color:lightblue;" >
			
			
			
			</td>
			<td style="background-color:lightblue;" >
			
			<form>
			    <a href="c_replay2.php">Chat</a> &nbsp;

				<a href="c_inbox2.php">Inbox</a>
			    
				
			
			</form>
			
			</td>
			<td style="background-color:lightblue;">
			<form>
			   <a href="new.php" target="_blank">Choose Worker</a>
				<ul style="list-style-type:none;"> 
				    <li><a href="customer_time.php">Time Schedule</a></li>
					
				   
				</ul>
			    
                
			
			</form>
			</td>
			<td style="background-color:lightblue;"><a href="">About</a>
			    <ul style="list-style-type:none;"> 
				    <li><a href="customers_profile.php">My Profile</a></li>
					<li><a href="customers_RemoveAccount.php">Remove Account</a></li>
					</ul>
			
			
			
			</td>
			<td style="background-color:lightblue;"><a href="logout.php">Log Out</a></td>
		<tr>
	</table><br/>
	<table width="100%">
	    <tr> 
		    <td style="background-color:lightgray;">
			<marquee style="background-color:lightorange"><h1>Thank you,For visiting Our Website.Stay with us.</h1></marquee>
			<marquee><h1></h1></marquee>
			
			
			
			</td>
		
		
		</tr>
	
	</table>
	
	
	
	

   
<a href="terms_Policy.php"><h4>Terms and Polices</h4></a>
</body>
</html>