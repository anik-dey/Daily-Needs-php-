


<!DOCTYPE html>
<html>
<head>
	<title>Terms & Conditions</title>
</head>
<body>
	<table  align="center" width="60%">
	<tr>
		<th><h1>Terms & Conditions</h1></th>
	</tr>
	<tr>
		<th><h4>Last Updated: 27/4/2019</h4></th>
	</tr>
	<tr>
		<th align="left">
			<h3>Welcome to daily-needs.com</h2>
				<p>The following terms and conditions (these "Terms of Service"), govern your access to and use of the Fiverr website, including any content, functionality and services offered on or through www.fiverr.com (the "Site"), by Fiverr International Ltd. and its subsidiaries Fiverr Limited. (Lemesou 11, 2112 Nicosia, Cyprus) and Fiverr Inc. (38 Greene St. NY 10013, NY), as applicable (collectively, "Fiverr" "we" or "us").

				Please read the Terms of Service carefully before you start to use the Site. By using the Site, opening an account or by clicking to accept or agree to the Terms of Service when this option is made available to you, you accept and agree to be bound and abide by these Terms of Service and our Privacy Policy, found here, incorporated herein by reference. If you do not want to agree to these Terms of Service or the Privacy Policy, you must not access or use the Site. For more detailed policies surrounding the activity and usage on the Site, please access the designated articles herein.

				This Site is offered and available to users who are 13 years of age or older. If you are under 13 you may not use this Site or the Fiverr services. By using this Site, you represent and warrant that you are of legal age to form a binding contract and meet all of the foregoing eligibility requirements. If you do not meet all of these requirements, you must not access or use the Site.

				Our Customer Support team is available 24/7 if you have any questions regarding the Site or Terms of Service. Contacting our Customer Support team can be performed by submitting a request here.
				</p>
		</th>			
	</tr>
	<tr>
		<th align="left">
			<h2>Key Terms</h2>
			<ul>
				<li>Buyers are users who purchase services on Fiverr.</li>
				<li>Custom Orders are requests made by a Buyer to receive a Custom Offer from a Seller.</li>
				<li>Disputes are disagreements experienced during an order between a Buyer and Seller on Fiverr.</li>
				<li>Balance is the aggregated amount of your Revenue as a Seller and/or returned payments from cancelled orders as a Buyer.</li>
				<li>Credits are credits that Fiverr may provide users to be used only for purchases on Fiverr, subject to these Terms of Service or any other applicable laws and/or terms.</li>
				<li>Orders are the formal agreement between a Buyer and Seller after a purchase was made from the Seller’s Gig Page.</li>
				<li>Only registered users may buy and sell on Fiverr. Registration is free.</li>
			</ul>
		</th>
	</tr>

	<tr>
		<th align="left">
			<h2>Overview (Main terms, in a nutshell)</h2>
			<ul>
				<li>Buyers are users who purchase services on Fiverr.</li>
				<li>Custom Orders are requests made by a Buyer to receive a Custom Offer from a Seller.</li>
				<li>Disputes are disagreements experienced during an order between a Buyer and Seller on Fiverr.</li>
				<li>Balance is the aggregated amount of your Revenue as a Seller and/or returned payments from cancelled orders as a Buyer.</li>
				<li>Credits are credits that Fiverr may provide users to be used only for purchases on Fiverr, subject to these Terms of Service or any other applicable laws and/or terms.</li>
				<li>Orders are the formal agreement between a Buyer and Seller after a purchase was made from the Seller’s Gig Page.</li>
				<li>Only registered users may buy and sell on Fiverr. Registration is free.</li>
			</ul>
		</th>
	</tr>

	</table>
</body>
</html>
t&c.php
Displaying t&c.php.