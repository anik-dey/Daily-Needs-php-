<?php
session_start();
if(!isset($_SESSION['name']))
{
	header("Location:user_login.php");
}
?>

<html>
<head>
<title>
worker Hired
</title>
</head>
<body>
<?php
		$name=$_SESSION['name'];
		
		?>
<h3 align="left"><a href="worker_home.php"><img src="images.png" height="60px" width="110px" ></a></h3>
<h3 align="right"><a href="logout.php">Log Out</a>
   <h1 align="center">DAILY NEEDS</h1><br/>
   <h2 align="center">Select Hired Schedule : </h2>
   <form method="post">
   <table align="center">
   <tr>
   <td>
   <select class="text" name="hired" id="hired">
      
      <option value="morning">8am - 11am</option>
      <option value="noon">11am - 2pm</option>
      <option value="evening">2pm - 5pm</option>
    
    </td>
    </tr>
     <tr>
     <td>
    <br/> <input type="submit" name="submit" value="Hired"/> 
     </td>
     </tr>
     
    </table>
    </form>
</body>
</html>
<?php
if(isset($_POST['submit']))
{
$id=$_SESSION['id'];

$schedule=$_POST['hired'];

$con=mysqli_connect("localhost","root","","webproject");
if(!$con)
{
  die("Connection Error: ".mysqli_connect_error()."<br/>");
  }
  $sql="SELECT * FROM registrationtable WHERE id='$id'";
  $result=mysqli_query($con,$sql);
  if(mysqli_num_rows($result)>0)
	{
		$row=mysqli_fetch_array($result);
		$_SESSION['name']=$row['name'];
        $phone=$row['phoneNumber'];
        $name=$row['name'];
        $type=$row['type'];
        
        
    }    


  if($schedule == "morning")
  {
    
    $morning="8am - 11am";
    $sql="INSERT INTO hired (id,name,schedule,date,phone,type) VALUES('$id','$name','$morning',NOW(),'$phone','$type')";
    $result=mysqli_query($con,$sql);
    $sql="DELETE FROM morning WHERE id='$id'";
    $result=mysqli_query($con,$sql);
  }
  else if($schedule =="noon")
  {
    $noon="8am - 11am";
    $sql="INSERT INTO hired (id,name,schedule,date,phone,type) VALUES('$id','$name','$noon',NOW(),'$phone','$type')";
    $result=mysqli_query($con,$sql);
    $sql="DELETE FROM noon WHERE id='$id'";
    $result=mysqli_query($con,$sql);
  }
  else if($schedule = "evening")
  {
    $evening="8am - 11am";
    $sql="INSERT INTO hired (id,name,schedule,date,phone,type) VALUES('$id','$name','$evening',NOW(),'$phone','$type')";
    $result=mysqli_query($con,$sql);
    $sql="DELETE FROM evening WHERE id='$id'";
    $result=mysqli_query($con,$sql);
  }

} 
?>