<?php
session_start();
$hdr="";
 if (isset($_POST['submit']))
 {

 	$username=$_POST['username'];
 	$password=$_POST['password'];
 	if($_POST['username'] == "")
 	{
 		$error_msg['username']="Username cannot be empty";
 	}
 	if($_POST['password'] == "")
 	{
 		$error_msg['password']="Password cannot be empty";
 	}

 	
 	$con=mysqli_connect("localhost","root","","webproject");
	if(!$con)
	{
		die("Connection Error: ".mysqli_connect_error()."<br/>");
	}
	//Retrieve Data

	$password=$_POST['password'];
	$username=$_POST['username'];
	$sql="SELECT * FROM registrationtable WHERE username='$username' AND password='$password'";
	$result=mysqli_query($con,$sql);	
	if(mysqli_num_rows($result)>0)
	{
		$row=mysqli_fetch_array($result);
		$_SESSION['name']=$row['name'];
		$_SESSION['status']=$row['status'];
		$_SESSION['id']=$row['id'];
		if($_SESSION['status']==1)
		{
			
			header("Location:customer_home.php");
			exit();
			
		}

		else if($_SESSION['status']==2)
		{
			dateExpire();
			header("Location:worker_home.php");
		}

		else if($_SESSION['status']==0)
		{
			header("Location:adminhome.php");
		}
		//header("Location:home.php");
	}
	else
	{
		echo "No data found.<br/>";
	}

	
      mysqli_close($con);		
      


 } 

?>




<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body style="background-color:cyan;">
	<h1 align="center">DAILY NEEDS</h1>
   <h2 align="center">Login Form</h2>
  <form action="<?= htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
  <table align="center">
  	<tr class="row">
  		<td class="label"><?php echo $hdr; ?> <label for="username">Username</label></td><br/>
  		<td><input type="text" name="username" placeholder="Username" />
  		
         <?php
				if (isset($error_msg['username'])) 
				{
					echo $error_msg['username'];
				}
				?>
  		</td>
  	</tr>
  	 <tr>
    	<td></td>
    </tr>
  	<tr class="row">
  		
  		<td class="label"><label for="username">Password</label></td><br/>
  		<td><input type="password" name="password" placeholder="Password" />
  		
         <?php
				if (isset($error_msg['password'])) 
				{
					echo $error_msg['password'];
				}
				?>

		</td>		
  		
  	</tr>
    
    <tr>
    	<td></td>
    </tr>
    <tr>
       	<td colspan="4"><input type="submit" name="submit" value="Login"/></td>
       	
       	<td></td>
       </tr>
    <tr>
    	<td colspan="2"><h4 style="color:Tomato;">Not Yet Registered??</h4></td>

    </tr>
    <tr>
    	<td>
    			<a href="user_rgtn.php"><input type="button" name="register_btn" value="Click here to Register"/></a>
    	</td>
    </tr>

  </table>
  <table align="center">
		<tr>
			<td><h4 style="color:black;">Kindly login to help us to serve you better.</h4></td>
		</tr>
	</table>
  </form>	
</body>
</html>

<?php
function dateExpire()
{
	$con=mysqli_connect("localhost","root","","webproject");
	if(!$con)
	{
		die("Connection Error: ".mysqli_connect_error()."<br/>");
	}
	$id=$_SESSION['id'];
    $sql="SELECT * FROM morning WHERE id='$id'";
	$result=mysqli_query($con,$sql);	
	if(mysqli_num_rows($result)>0)
	{
		$row=mysqli_fetch_array($result);
		$date=$row['date'];
	}
	$today = date("Y-m-d");
	if($date < $today)
	{
		$sql="DELETE FROM morning WHERE id='$id'";
         $result=mysqli_query($con,$sql);
	}

	$sql="SELECT * FROM noon WHERE id='$id'";
	$result=mysqli_query($con,$sql);	
	if(mysqli_num_rows($result)>0)
	{
		$row=mysqli_fetch_array($result);
		$date=$row['date'];
	}

	if($date < $today)
	{
		$sql="DELETE FROM noon WHERE id='$id'";
         $result=mysqli_query($con,$sql);
	}

	$sql="SELECT * FROM morning WHERE id='$id'";
	$result=mysqli_query($con,$sql);	
	if(mysqli_num_rows($result)>0)
	{
		$row=mysqli_fetch_array($result);
		$date=$row['date'];
	}

	if($date < $today)
	{
		$sql="DELETE FROM evening WHERE id='$id'";
         $result=mysqli_query($con,$sql);
	}





}
?>