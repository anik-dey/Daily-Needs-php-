<?php
 if(isset($_POST['submit1']))
{
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webproject";
$name1= $_POST["from"];
$name2= $_POST["to"];
$name3= $_POST["amessage"];

if($name1 != "Admin")
{
   echo"Must Be Typed Admin before Message";
   exit();
}
if
( empty($name1)== true || empty($name3)== true)

   {
   echo"Empty Field";
   exit();
    //header("Location:a_replay1.php");
   }




// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
     echo"not send";
}

$sql = "INSERT INTO inbox (sender, receiver, message)
VALUES ('".$name1."','".$name2."','".$name3."')";

if (mysqli_query($conn, $sql)) {
    echo "Message Sent Successfully";
    header("Location:a_replay1.php");
} 
else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    echo"Not Sent";
    }

mysqli_close($conn);
}
?>