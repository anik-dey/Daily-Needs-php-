<?php
    $servername2="localhost";
    $username2="root";
    $password2="";
    $dbname2="webproject";
if(isset($_POST['ok']))
{
	
	 $id= $_POST["id1"];
	   $name=$_POST["name1"];
	   $phonenumber=$_POST["phonenumber1"];
	   $gender=$_POST["gender1"];
	   $username=$_POST["username1"];
	   $password=$_POST["password1"];
	   $email=$_POST["email1"];
	   $status=$_POST["status1"];
	   $type=$_POST["type1"];
	
	
	
	
	// Create connection
    $conn = mysqli_connect($servername2, $username2, $password2, $dbname2);
     // Check connection
    if (!$conn) 
	{
     die("Connection failed: ". mysqli_connect_error());
    } 
	$sql = "UPDATE registrationtable SET id='$id',name='$name',phonenumber='$phonenumber',
    gender='$gender',username='$username',password='$password',email='$email',status='$status',type='$type'	WHERE id='$id'";
	if (mysqli_query($conn, $sql)) {
    echo "Record updated successfully";
	header("location:adminview.php");
	exit();
}
 else {
    echo "Error updating record: " . mysqli_error($conn);
}
}

mysqli_close($conn);


	




?>
	
	
	
	
	
	
	






	
	
	