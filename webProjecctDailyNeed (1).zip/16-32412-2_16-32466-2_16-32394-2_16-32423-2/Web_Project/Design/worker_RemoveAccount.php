<?php
session_start();
if(!isset($_SESSION['name']))
{
	header("Location:user_login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<script>
function validateForm() {
   
  var x = document.forms["myForm"]["fname"].value;
  if (x == "") {
    alert("Give Your Password");
    return false;
  }
 

  
  
 
}
</script>
</head>
<body>
<?php
		$name=$_SESSION['name'];
		
		?>
<h3 align="left"><a href="worker_home.php"><img src="images.png" height="60px" width="110px" ></a></h3>


<h1 align="center">Daily Needs</h1>
<table align="center">
<tr>
<form name="myForm" onsubmit="return validateForm()" method="post">
<tr>
 <td align="center">Current Password: <input type="text" name="fname"></td>
 
 </tr>
 <tr>
 <td align="center"> <input type="submit" name="submit" value="Confirm"></td>
 </tr>
</form>
</tr>
</table>

</body>
</html>
<?php
if(isset($_POST['submit']))

{
    $id=$_SESSION['id'];
    $con=mysqli_connect("localhost","root","","webproject");
    if(!$con)
    {
      die("Connection Error: ".mysqli_connect_error()."<br/>");
      }
      $sql="SELECT * FROM registrationtable WHERE id='$id'";
    $result=mysqli_query($con,$sql);	
    if(mysqli_num_rows($result)>0)
    {
      $row=mysqli_fetch_array($result);
          $_SESSION['password']=$row['password'];
    }

   if($_POST['fname']==$_SESSION['password'])
   {
    $sql="DELETE FROM registrationtable  WHERE id='$id'";
    $result=mysqli_query($con,$sql);
    $sql="DELETE FROM morning  WHERE id='$id'";
    $result=mysqli_query($con,$sql);
    $sql="DELETE FROM noon  WHERE id='$id'";
    $result=mysqli_query($con,$sql);
    $sql="DELETE FROM evening  WHERE id='$id'";
    $result=mysqli_query($con,$sql);
    header("Location:logout.php");
   }
   else {
    echo "Password do not match";
}
}
?>