<?php
session_start();
?>
<?php
    if(isset($_POST['search1']))
{
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webproject";
$search= $_POST["search"];
if(empty($search)== true)
{
	
echo"empty search";
   exit();
}
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
     echo"not send";
}

$sql = "SELECT * FROM registrationtable
WHERE id='$search' OR name='$search' OR phonenumber='$search' OR  username='$search' OR  email='$search'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      // echo "<br> id: ". $row["id"]. " Mail Address: ". $row["receiver"]. "<br>Message: " . $row["message"] . "<br>";
	   $id= $row["id"];
	   $name=$row["name"];
	   $phonenumber=$row["phoneNumber"];
	   $gender=$row["gender"];
	   $username=$row["username"];
	   $password=$row["password"];
	   $email=$row["email"];
	   $status=$row["status"];
	   $type=$row["type"];
	   
	   echo '<table  width="100%" style="background-color:lightblue;">
		<tr>
		<td>
		<Form align="center"method="POST" action="adminview.php">
		ID:</br>
        <input type="text"name="" value="'.$id.'"></br>	
        Name:</br>
        <input type="text" name="name" value="'.$name.'"></br>
		Phone Number:</br>
        <input type="text" name="phone" value="'.$phonenumber.'"></br>
		Gender:</br>
        <input type="text" name="gender" value="'.$gender.'"></br>
		User Name:</br>
        <input type="text" name="username" value="'.$username.'"></br>
		Password:</br>
        <input type="text" name="password" value="'.$password.'"></br>
		Email:</br>
        <input type="text" name="email" value="'.$email.'"></br>
		Status:</br>
        <input type="text" name="status" value="'.$status.'"></br>
		Worker Type:</br>
        <input type="text" name="type" value="'.$type.'"></br></br>
         
        <input type="submit"name="edit"value="View Details"> &nbsp
		
		
	
         </form>
		</td>
	    </tr>
		</table>';
    }
} else {
    echo "Empty Data base";
}

$conn->close();



}




?>

