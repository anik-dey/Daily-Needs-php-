<html>
<head><title>Workers</title></head>
<body style="background-color:gray;">
    <table width="100%" style="background-color:lightblue;">
        <tr align="right" style="background-color:lightblue;">
		    <td align="left"style="background-color:lightblue;"><a href="home.php"><img src="images.png" height="60px" width="110px" ></a></td>
			<td style="background-color:lightblue;" >
			
			<form>
			    What are you looking for?
			    <input type="text"name="search"value="">
				<input type="submit" name="submit"value="Search">
				
			
			</form>
			
			</td>
			<td style="background-color:lightblue;">
			<form>
			   <a href="home.php" target="_blank">Choose Worker</a>
				<ul> 
				    <li><a href="electricianD.php">Electrician</a></li>
					<li><a href="plumberD.php">plumber</a></li>
					<li><a href="cleanerD.php">cleaner</a></li>
					
				   
				</ul>
			    
                
			
			</form>
			</td>
			<td style="background-color:lightblue;"><a href="">About this site..</a></td>
			<td style="background-color:lightblue;"><a href="user_login.php">Log In</a></td>
		<tr>
	</table><br/>
	<table width="100%">
	    <tr> 
		    <td style="background-color:lightgray;">
			<marquee style="background-color:lightorange"><h1>Thank you,For visiting Our Website.Stay with us.</h1></marquee>
			<marquee><h1>Sign up for free and Get unbeliveable Offers..Grab your offer now...</h1></marquee>
			
			
			
			</td>
		
		
		</tr>
	
	</table>
	
	
	
	<h1 align="center">Select Workers<h1><br/>
	<table width="80%" align="center">
	    <tr>
            <td style="background-color:lightgreen;">Name: &nbsp Raaz <br/><br/>
			    type: &nbsp Cleaner<br/><br/>
				Skills:<br/><br/>
				Rating:4.9/5<br/><br/>
				Charge:300tk/hr<br/><br/>
				<a href="">View more..</a>
				
			
			</td>
            <td style="background-color:lightgreen;">Name:<br/><br/>
			    type:<br/><br/>
				Skills:<br/><br/>
				Rating:<br/><br/>
				Charge:300tk/hr<br/><br/>
				<a href="">View more..</a>
			
			
			</td>
            <td style="background-color:lightgreen;">Name:<br/><br/>
			    type:<br/><br/>
				Skills:<br/><br/>
				Rating:<br/><br/>
				Charge:300tk/hr<br/><br/>
				<a href="">View more..</a>
			
			
			</td>			
		
		
		
		
		</tr>

    </table><br/><br/>
		<table width="80%" align="center">
	    <tr>
            <td style="background-color:lightgreen;">Name: &nbsp Raaz <br/><br/>
			    type: &nbsp Cleaner<br/><br/>
				Skills:<br/><br/>
				Rating:4.9/5<br/><br/>
				Charge:300tk/hr<br/><br/>
				<a href="">View more..</a>
				
			
			</td>
            <td style="background-color:lightgreen;">Name:<br/><br/>
			    type:<br/><br/>
				Skills:<br/><br/>
				Rating:<br/><br/>
				Charge:300tk/hr<br/><br/>
				<a href="">View more..</a>
			
			
			</td>
            <td style="background-color:lightgreen;">Name:<br/><br/>
			    type:<br/><br/>
				Skills:<br/><br/>
				Rating:<br/><br/>
				Charge:300tk/hr<br/><br/>
				<a href="">View more..</a>
			
			
			</td>			
		
		
		
		
		</tr>

    </table><br/><br/>
		<table width="80%" align="center">
	    <tr>
            <td style="background-color:lightgreen;">Name: &nbsp Raaz <br/><br/>
			    type: &nbsp Cleaner<br/><br/>
				Skills:<br/><br/>
				Rating:4.9/5<br/><br/>
				Charge:300tk/hr<br/><br/>
				<a href="">View more..</a>
				
			
			</td>
            <td style="background-color:lightgreen;">Name:<br/><br/>
			    type:<br/><br/>
				Skills:<br/><br/>
				Rating:<br/><br/>
				Charge:300tk/hr<br/><br/>
				<a href="">View more..</a>
			
			
			</td>
            <td style="background-color:lightgreen;">Name:<br/><br/>
			    type:<br/><br/>
				Skills:<br/><br/>
				Rating:<br/><br/>
				Charge:300tk/hr<br/><br/>
				<a href="">View more..</a>
			
			
			</td>			
		
		
		
		
		</tr>

    </table>

<a href=""><h3>Report</h3></a>
<a href=""><h4>Turms and Polices</h4></a>
</body>
</html>