<?phpinclude_once("a_inbox1.php");
   // global $receiver1=$_GET[$row["receiver"]]; 
 ?>
<html>
<head><title>Admin Inbox</title></head>
<body style="background-color:gray;">
    <table width="100%" style="background-color:lightblue;">
        <tr align="right" style="background-color:lightblue;">
		    <td align="left"style="background-color:lightblue;"><a href="adminhome.php"><img src="images.png" height="60px" width="110px" ></a></td>
			<td style="background-color:lightblue;" >
			
			
			</td>
			<td style="background-color:lightblue;">
			</td>
			
			<td style="background-color:lightblue;"><a href="user_login.php">Log Out</a></td>
		<tr>
		<tr>
		<td>
		<Form align="center"method="POST" action="adb.php">
		From:</br>
		<input type="text"name="from" value=""placeholder= " Type 'Admin' here"></br>
		To:</br>
        <input type="email"name="to" value="" placeholder="Enter receiver's mail adrress"></br>	
        Message:</br>

       <input type="text"name="amessage"value=""placeholder=" Enter your message here...">
        </br></br>
        <input type="submit"name="submit1"value="Send">
         </form>
		
		
		</td>
		
		
		</tr>
		</table>
		
		</body>
		</html>
		<?php //echo $_POST[$receiver]?>