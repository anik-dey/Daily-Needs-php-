<?php
 if(isset($_POST['submit1']))
{
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webproject";
$cname1= $_POST["cfrom"];
$cname2= $_POST["cto"];
$cname3= $_POST["cmessage"];

if($cname2 != "Admin")
{
   echo"Must Be Typed Admin before Message";
   exit();
}
if
( empty($cname2)== true || empty($cname3)== true)

   {
   echo"Empty Field";
   exit();
    //header("Location:a_replay1.php");
   }




// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
     echo"not send";
}

$sql = "INSERT INTO inbox (sender, receiver, message)
VALUES ('".$cname1."','".$cname2."','".$cname3."')";

if (mysqli_query($conn, $sql)) {
    echo "Message Sent Successfully";
    header("Location:c_replay2.php");
} 
else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    echo"Not Sent";
    }

mysqli_close($conn);
}
?>