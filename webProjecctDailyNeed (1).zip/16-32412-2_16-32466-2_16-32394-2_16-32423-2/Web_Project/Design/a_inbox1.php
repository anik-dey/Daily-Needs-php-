<html>
<head><title>Admin Replay</title></head>
<body style="background-color:gray;">
    <table width="100%" style="background-color:lightblue;">
        <tr align="right" style="background-color:lightblue;">
		    <td align="left"style="background-color:lightblue;"><a href="adminhome.php"><img src="images.png" height="60px" width="110px" ></a></td>
			<td style="background-color:lightblue;" >
			
			 
			</td>
			<td style="background-color:lightblue;">
			</td>
			
			<td style="background-color:lightblue;"><a href="user_login.php">Log Out</a></td>
		</tr>
		</table> 
		
 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webproject";
Global $sender,$message,$id;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT id,receiver,sender,message FROM inbox Where receiver='Admin'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      // echo "<br> id: ". $row["id"]. " Mail Address: ". $row["receiver"]. "<br>Message: " . $row["message"] . "<br>";
	   $id= $row["id"];
	   $receiver=$row["sender"];
	   $message=$row["message"] ;
	   echo '<table  width="100%" style="background-color:lightblue;">
		<tr>
		<td>
		<Form align="center"method="POST" action="a_replay1.php">
		From:</br>
        <input type="text"name="" value="'. $receiver.'"></br>	
        Your Message:</br>
        <input type="text" name="message1" value="'. $message.'">
         </textarea></br></br>
        <input type="submit"name="submit2"value="replay"> &nbsp
		
		
	
         </form>
		</td>
	    </tr>
		</table>';
    }
} else {
    echo "n0 result folund";
}

$conn->close();
?> 

		
		</body>
		</html>
