<?php
session_start();
if(!isset($_SESSION['name']))
{
	header("Location:user_login.php");
}
?>
<html>
<head>
	<title>Time Booking</title>
</head>
<body style="background-color:gray;">
<?php
		$name=$_SESSION['name'];
		
		?>

 <h3 align="left"><a href="worker_home.php"><img src="images.png" height="60px" width="110px" ></a></h3>
 <h3 align="right"><a href="logout.php">Log Out</a>
<h1 align="center">DAILY NEEDS</h1>

   <h2 align="center">MY JOB</h2>
   <form method="POST" onsubmit="return validation()">
 
   <table align="center">
   <tr>
   <td>
   <select class="text" name="time" id="time">
      <option value="NULL">--Select Schedule--</option>
      <option value="morning">8am-11am</option>
      <option value="noon">11am-2pm</option>
      <option value="evening">2pm-5pm</option>
    

     </select></td>
     
   </tr><br/>
   
   <tr>
   <td>
   <select class="text" name="area" id="area">
      <option value="NULL">--Select Area--</option>
      <option value="banani">Banani</option>
      <option value="gulshan">Gulshan</option>
      <option value="kilkhet">Khilkhet</option>
    <option value="uttra">Uttra</option>

     </select></td>
   </tr>

   </table><br/>
   <table align="center">
   <tr>
   <td>Payment Amount</td>
   <td><input type="text" id="pay" name="amount"/></td>
   </tr>
   <tr>
    <td></td>
    <td><input type="submit" name="submit" value="Confirm"/></td>
    </tr>
   </table><br/><br/><br/>
   <table width="100%">
	    <tr> 
		    <td style="background-color:gray;">
			<marquee style="background-color:lightorange"><h1>Active More Earn More</h1></marquee>
			</td>
		</tr>
  
   
   </form>
</body>
</html>

<?php
 $id=$_SESSION['id'];
 $con=mysqli_connect("localhost","root","","webproject");
 if(!$con)
 {
   die("Connection Error: ".mysqli_connect_error()."<br/>");
   }
   $sql="SELECT * FROM registrationtable WHERE id='$id'";
 $result=mysqli_query($con,$sql);	
 if(mysqli_num_rows($result)>0)
 {
   $row=mysqli_fetch_array($result);
       $_SESSION['name']=$row['name'];
       $_SESSION['phone']=$row['phoneNumber'];
       $_SESSION['email']=$row['email'];
       $_SESSION['type']=$row['type'];
      
       $_SESSION['id']=$row['id'];
  }  
  if(isset($_POST['submit']))  
  {
    $time=$_POST['time'];
    $area=$_POST['area'];
    $amount=$_POST['amount'];
    $type=$_SESSION['type'];
    $name=$_SESSION['name'];
    $phone=$_SESSION['phone'];
    $email=$_SESSION['email'];
    $id=$_SESSION['id'];
    $con=mysqli_connect("localhost","root","","webproject");
 if(!$con)
 {
   die("Connection Error: ".mysqli_connect_error()."<br/>");
   }
   
   if($time == "morning")
   {
    $sql="SELECT * FROM morning WHERE id='$id'";
    $_SESSION['id1']=$row['id'];
    $id1=$_SESSION['id1'];
    if($_SESSION['id1'])
    {
      
      $sql="DELETE FROM morning WHERE id='$id1'";
      $result=mysqli_query($con,$sql);
    }
  
    $sql="INSERT INTO morning (id,name,phoneNumber,email,type,amount,area,date) VALUES('$id','$name','$phone','$email','$type','$amount','$area',NOW())";
    $result=mysqli_query($con,$sql);
  }
  else if($time == "noon")
   {
    $sql="SELECT * FROM noon WHERE id='$id'";
    $_SESSION['id2']=$row['id'];
    $id2=$_SESSION['id2'];
    if($_SESSION['id2'])
    {
      $sql="DELETE FROM noon WHERE id='$id2'";
      $result=mysqli_query($con,$sql);
    }
    $sql="INSERT INTO noon (id,name,phoneNumber,email,type,amount,area,date) VALUES('$id','$name','$phone','$email','$type','$amount','$area',NOW())";
    $result=mysqli_query($con,$sql);
   }
  else if($time == "evening")
   {
    $sql="SELECT * FROM evening WHERE id='$id'";
    $_SESSION['id3']=$row['id'];
    $id3=$_SESSION['id3'];
    if($_SESSION['id3'])
    {
      
      $sql="DELETE FROM evening WHERE id='$id3'";
      $result=mysqli_query($con,$sql);

    }
    
    $sql="INSERT INTO evening (id,name,phoneNumber,email,type,amount,area,date) VALUES('$id','$name','$phone','$email','$type','$amount','$area',NOW())";
    $result=mysqli_query($con,$sql);
   }
  }
?>



<script>
    function validation(){
        if(document.getElementById('pay').value=="")
        {
            alert('Payment Amount can not be empty');
            return false;
        }
       
    }
    </script>
    <?php
   if(isset($_POST['submit']))
   {
     header("Location:worker_home.php");  
   }
    ?>