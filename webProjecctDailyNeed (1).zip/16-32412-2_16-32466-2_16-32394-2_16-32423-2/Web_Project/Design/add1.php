<?php
require ('config.php');
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($con, $_POST["query"]);
 $query = "SELECT * FROM noon
WHERE  area  LIKE '%".$search."%'
  
 ";}
else
{
 $query = "SELECT * FROM noon";
}
$result = mysqli_query($con, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
  <div class="table-responsive">
   <table class="table table bordered">
   <tr>
     <th>ID</th>
     <th>Name</th>
     <th>Email</th>
     <th>Phone</th>
     <th>Base Amount</th>
     <th>Area</th>
     <th>Type</th>
    </tr>';
 while($row1 = mysqli_fetch_array($result))
 {
  $output .= '
  <tr>
    <td>'.$row1["id"].'</td>
    <td>'.$row1["name"].'</td>
    <td>'.$row1["email"].'</td>
    <td>'.$row1["phoneNumber"].'</td>
    <td>'.$row1["amount"].'</td>
    <td>'.$row1["area"].'</td>
    <td>'.$row1["type"].'</td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo "Record Not Found";
}
?>