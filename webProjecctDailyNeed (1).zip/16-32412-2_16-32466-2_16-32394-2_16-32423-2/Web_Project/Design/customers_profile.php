<?php
session_start();
$id=$_SESSION['id'];
loadWorker();
if(!isset($_SESSION['name']))
{
	header("Location:user_login.php");
}
//function updateProfile($user);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Profile</title>
</head>
<body style="background-color:cyan;">
<?php
		$name=$_SESSION['name'];
		
		?>
<a href="customer_home.php"><img src="images.png" height="60px" width="110px" ></a></td>
<h3 align="right"><a href="logout.php">Log Out</a>
<h1 align="center">DAILY NEEDS</h1>
 
    <h1 align="center">My Profile</h1>
    <p id="m"></p>
    <form method="POST">
        <table align="center">
        <tr>
         <td>Id</td>
         <td><label><?php echo $id ?></label></td>
        </tr> 
        <tr>
        <td>Name</td>
        <td><input type="text" name="name" value="<?php echo isset($_SESSION['name']) ? $_SESSION['name'] : ''; ?>"/></td>  
        </tr>
        <tr>
        <td>Email</td>
        <td><input type="text" name="email" value="<?php echo isset($_SESSION['email']) ? $_SESSION['email'] : ''; ?>"/></td> 
        </tr>
         
        <td>Phone</td>
        <td><input type="text" name="phone" value="<?php echo isset($_SESSION['phone']) ? $_SESSION['phone'] : ''; ?>"/></td> 
        </tr>

        <td>Username</td>
        <td><input type="text" name="username" value="<?php echo isset($_SESSION['username']) ? $_SESSION['username'] : ''; ?>"/></td> 
        </tr>
        <td>Password</td>
        <td><input type="text" name="password" value="<?php echo isset($_SESSION['password']) ? $_SESSION['password'] : ''; ?>"/></td> 
        </tr>
        <tr align="cemter">
       <td> <input type="submit" name="submit" value="Update"/></td>;
        </tr>
        </table>
    </form>
</body>
</html>
<?php
function loadWorker()
{
    $id=$_SESSION['id'];
    $con=mysqli_connect("localhost","root","","webproject");
	if(!$con)
	{
		die("Connection Error: ".mysqli_connect_error()."<br/>");
    }
    $sql="SELECT * FROM registrationtable WHERE id='$id'";
	$result=mysqli_query($con,$sql);	
	if(mysqli_num_rows($result)>0)
	{
		$row=mysqli_fetch_array($result);
		$_SESSION['name']=$row['name'];
        $_SESSION['phone']=$row['phoneNumber'];
        $_SESSION['email']=$row['email'];
        $_SESSION['username']=$row['username'];
        $_SESSION['password']=$row['password'];
        $_SESSION['id']=$row['id'];
        
        
    }    
}

?>



<?php
if(isset($_POST['submit']))
{
     $name=$_POST['name'];
     $email=$_POST['email'];
     $phone=$_POST['phone'];
     $username=$_POST['username'];
     $password=$_POST['password'];

     if($_POST['name'] == "")
     {
         
     $error_msg['name'] = "Name is require";

     
     }

     
     if(!preg_match("/^[a-zA-Z -]*$/",$name))
     {
         
         $error_msg['name']="Only letters are allowed";
         
          
     }

     if($_POST['phone'] == "")
     {
         
     $error_msg['phone'] = "Phone Num is require";
     
     
     }
  else if (!is_numeric($phone)) 
     {
         
         
         $error_msg['phone']="Only Number input";
         
     }
     else if(strlen($phone) !=11)
     {
         
         
         $error_msg['phone']="Only input 11 digits number";
         
     }

     if(empty($_POST['username']))
     {
         
         
         $error_msg['username']="Username is require";
         
     }

     else if (!(preg_match("/^[A-Za-z][A-Za-za-z0-9]{5,100}$/",$username))) 
      {
          
          
          $error_msg['username']="Length at least 6 require ";
          
      }
      if(empty($_POST['password']))
      {
          
          $error_msg['pass2']="Confirm Password is require";
          
      }
      else if(strlen($password)<6) 
      {
      
          $error_msg['pass4']="Password at least 6 Length";
          
      }
      if(!filter_var($email,FILTER_VALIDATE_EMAIL))
      {
          
          $error_msg['email']="Invalid email number";
      
      } 

      if(!$error_msg)
 {

     $id=$_SESSION['id'];
     $con=mysqli_connect("localhost","root","","webproject");
     if(!$con)
     {
         die("Connection Error: ".mysqli_connect_error()."<br/>");
     }
      
    $sql="UPDATE registrationtable SET name='$name',phoneNumber='$phone',email='$email',username='$username',password='$password' WHERE id='$id'";
    $result=mysqli_query($con,$sql);
    if(mysqli_query($con,$sql))
    {
        header("Location:user_login.php");
    }

 } 
 else{echo "Please correctly Fill Up the ...!!";}
}

?>