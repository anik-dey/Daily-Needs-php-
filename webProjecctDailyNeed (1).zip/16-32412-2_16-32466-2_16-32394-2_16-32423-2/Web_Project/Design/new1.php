<html>
<head><title>View Details</title></head>
<body style="background-color:gray;">
    <table width="100%" style="background-color:lightblue;">
        <tr align="right" style="background-color:lightblue;">
		    <td align="left"style="background-color:lightblue;"><a href="adminhome.php"><img src="images.png" height="60px" width="110px" ></a></td>
			<td style="background-color:lightblue;" >
			
			 
			</td>
			<td style="background-color:lightblue;">
			</td>
			
			<td style="background-color:lightblue;"><a href="login.php">Log Out</a></td>
		</tr>
		</table> 
		
 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webproject";
Global $id,$name,$phonenumber,$gender,$username,$password,$email,$status,$type;
 $id=$_POST['id1'];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT id,name,phonenumber,gender,username,password,email,status,type FROM registrationtable Where status='1' OR status='2' AND id='$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      // echo "<br> id: ". $row["id"]. " Mail Address: ". $row["receiver"]. "<br>Message: " . $row["message"] . "<br>";
	   $id= $row["id"];
	   $name=$row["name"];
	   $phonenumber=$row["phonenumber"];
	   $gender=$row["gender"];
	   $username=$row["username"];
	   $password=$row["password"];
	   $email=$row["email"];
	   $status=$row["status"];
	   $type=$row["type"];
	   
	   echo '<table  width="100%" style="background-color:lightblue;">
		<tr>
		<td>
		<Form align="center"method="POST" action="new2.php">
		ID:</br>
        <input type="text"name="id1" readonly value="'.$id.'"></br>	
        Name:</br>
        <input type="text" name="name1" value="'.$name.'"></br>
		Phone Number:</br>
        <input type="text" name="phonenumber1" value="'.$phonenumber.'"></br>
		Gender:</br>
        <input type="text" name="gender1" value="'.$gender.'"></br>
		User Name:</br>
        <input type="text" name="username1" value="'.$username.'"></br>
		Password:</br>
        <input type="text" name="password1" value="'.$password.'"></br>
		Email:</br>
        <input type="text" name="email1" value="'.$email.'"></br>
		Status:</br>
        <input type="text" name="status1" value="'.$status.'"></br>
		Worker Type:</br>
        <input type="text" name="type1" value="'.$type.'"></br></br>
		<input type="submit"name="ok"value="Ok">&nbsp
		<input type="submit"name="cancel"value="Cancel">&nbsp
		
	
         </form>
		</td>
	    </tr>
		</table>';
    }
} else {
    echo "Empty Data base";
}

$conn->close();
?> 

		
		</body>
		</html>
