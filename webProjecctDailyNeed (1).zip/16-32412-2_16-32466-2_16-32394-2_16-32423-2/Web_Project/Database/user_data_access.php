<?php
include_once("../Database/db.php");
function getUserById($id){
    $query="SELECT * FROM registrationtable WHERE id=$id";
    $result=executeQuery($query);
    $user=null;
    if($result){
        $user=mysqli_fetch_assoc($result);
    }
    return $user;
}

?>